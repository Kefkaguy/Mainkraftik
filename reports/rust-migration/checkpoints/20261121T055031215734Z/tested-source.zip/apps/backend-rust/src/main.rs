//! Migration tools only. There is deliberately no deployable `serve` or order
//! command while the full migration coverage and cutover gates are incomplete.
use anyhow::{Context, Result};
use clap::{Parser, Subcommand};
use mainkraft::models::NumericModel;
use serde::Deserialize;
use std::{hint::black_box, path::PathBuf, time::Instant};

#[derive(Parser)]
#[command(
    name = "mainkraft",
    about = "Native Mainkraft migration verification tools"
)]
struct Cli {
    #[command(subcommand)]
    command: Command,
}
#[derive(Subcommand)]
enum Command {
    /// Read and verify existing content-addressed research records without writing.
    VerifyEvidence {
        #[arg(long)]
        root: PathBuf,
        #[arg(long)]
        compressed: bool,
    },
    /// Benchmark an identical, non-submitting numeric parity workload.
    BenchmarkNumeric {
        #[arg(long)]
        fixture: PathBuf,
        #[arg(long, default_value_t = 30)]
        iterations: usize,
    },
}
#[derive(Deserialize)]
struct Fixture {
    numeric: Vec<Case>,
}
#[derive(Deserialize)]
struct Case {
    artifact: NumericModel,
    inputs: Vec<Vec<Option<f64>>>,
}

fn main() -> Result<()> {
    match Cli::parse().command {
        Command::VerifyEvidence { root, compressed } => {
            let mut count = 0usize;
            for entry in
                std::fs::read_dir(root.join(if compressed { "compressed" } else { "records" }))
                    .context("evidence folder")?
            {
                let entry = entry.context("evidence entry")?;
                let path = entry.path();
                if compressed
                    && path
                        .file_name()
                        .is_some_and(|s| s.to_string_lossy().ends_with(".json.gz"))
                {
                    let key = path
                        .file_name()
                        .and_then(|s| s.to_str())
                        .and_then(|s| s.strip_suffix(".json.gz"))
                        .context("compressed ID")?;
                    mainkraft::evidence::Store::new(
                        &root,
                        mainkraft::evidence::Family::Compressed,
                        256 * 1024 * 1024,
                    )?
                    .record(key)
                    .with_context(|| format!("compressed integrity failed: {key}"))?;
                    count += 1;
                } else if !compressed && path.extension().is_some_and(|ext| ext == "json") {
                    let key = path
                        .file_stem()
                        .and_then(|v| v.to_str())
                        .context("evidence ID")?;
                    mainkraft::report_api::read_record(&root, key)
                        .with_context(|| format!("evidence integrity failed: {key}"))?;
                    count += 1;
                }
            }
            println!(
                "{}",
                serde_json::json!({"verified_records":count,"writes":0,"execution_authority":false})
            );
        }
        Command::BenchmarkNumeric {
            fixture,
            iterations,
        } => {
            let data: Fixture =
                serde_json::from_slice(&std::fs::read(fixture)?).context("numeric fixture")?;
            // Warm up once outside the timed loop, matching the Python harness.
            for case in &data.numeric {
                for row in &case.inputs {
                    black_box(case.artifact.predict(row)?);
                }
            }
            let start = Instant::now();
            let mut checksum = 0.0;
            let mut predictions = 0usize;
            for _ in 0..iterations {
                for case in &data.numeric {
                    for row in &case.inputs {
                        let prediction = case.artifact.predict(black_box(row))?;
                        checksum +=
                            prediction.expected_net_return + prediction.probability_positive;
                        predictions += 1;
                    }
                }
            }
            let seconds = start.elapsed().as_secs_f64();
            println!(
                "{}",
                serde_json::json!({"implementation":"rust","scope":"single-row numeric inference only; not full trading service","iterations":iterations,
                "predictions":predictions,"compute_wall_seconds":seconds,"predictions_per_second":predictions as f64/seconds,"checksum":checksum})
            );
        }
    }
    Ok(())
}
