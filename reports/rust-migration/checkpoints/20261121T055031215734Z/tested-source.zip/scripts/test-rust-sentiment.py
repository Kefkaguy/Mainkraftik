"""Offline native sentiment parity against pinned local model and ONNX runtime."""
import os
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
oracle=ROOT/'.local/rust-migration/sentiment-oracle'
python=oracle/'Scripts/python.exe'
library=oracle/'Lib/site-packages/onnxruntime/capi/onnxruntime.dll'
model=ROOT/'.local/models/distilroberta-financial-q8'
assert python.is_file() and library.is_file() and model.is_dir(),'Provision the pinned local sentiment reference environment first'
result=subprocess.run([str(python),'scripts/generate-rust-sentiment-inference-fixture.py'],cwd=ROOT)
if result.returncode:sys.exit(result.returncode)
env=dict(os.environ)
env['RUST_SENTIMENT_MODEL_DIR']=str(model)
env['RUST_SENTIMENT_LIBRARY']=str(library)
result=subprocess.run(['cargo','test','--manifest-path','apps/backend-rust/Cargo.toml','--features','sentiment-inference','--test','sentiment_inference','--','--ignored','--nocapture'],cwd=ROOT,env=env)
if result.returncode:sys.exit(result.returncode)
result=subprocess.run(['cargo','test','--manifest-path','apps/backend-rust/Cargo.toml','--features','sentiment-inference','--lib','sentiment_worker::tests::native_http_contract_and_cancellation_keep_single_inference_job','--','--ignored','--nocapture'],cwd=ROOT,env=env)
sys.exit(result.returncode)
